//Prevent Spoilers


//Solution: Reveal

//THE PLAN!
//1. Hide the Spoiler
 $(".spoiler span").hide();
//2. Add a button
$(".spoiler").append("<button>Reveal Spoiler!</button>")
// 3. When the Button is pressed action
$("button").click(function() {
    //3.1 Show Spoil next to the button clicked
      $(this).prev().show();
    //3.2 Get rid of button
      $(this).remove();
});


//4. Reavel the Spoiler


