 //Problem: User Clicking image goes to a dead end

//Solution: Creating a Overlay with the large image

var $overlay = $('<div id="overlay"></div>');
var $image = $("<img>");
var $caption = $("<p></p>");


 // An Image to overlay
 $overlay.append($image);

//A Caption to the overlay
$overlay.append($caption);

//Add the overlay
$("body").append($overlay);
 
//Capture a click event on a link to an image
  $ ("#imageGallery a").click(function( event ){
    event.preventDefault();
    var imageLocation = $(this).attr("href")
    
//Update overlay with the image linked in the link
    
    
$image.attr("src", imageLocation);  
   
  
    // Show the overlay
$overlay.show();

  // Get childs alt attribute and set caption
var captionText = $(this).children("img").attr("alt");
$caption.text(captionText);
  
  });


//When overlay is clicked
$overlay.click(function(){
  //Hide the Overlay
  $overlay.hide();
});